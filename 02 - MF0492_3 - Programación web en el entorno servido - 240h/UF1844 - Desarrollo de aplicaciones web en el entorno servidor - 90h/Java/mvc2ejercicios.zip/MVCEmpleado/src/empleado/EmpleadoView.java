package empleado;

public class EmpleadoView {
    public void mostrarEmpleado(String nombre, int edad, double salario) {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Salario: " + salario);
    }
}
